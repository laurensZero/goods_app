const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CZT1unEa.js","./mobile-core-Trt6sLFz.js"])))=>i.map(i=>d[i]);
import{r as t,_ as e}from"./mobile-core-Trt6sLFz.js";const a=t("CapacitorNfc",{web:()=>e(()=>import("./web-CZT1unEa.js"),__vite__mapDeps([0,1]),import.meta.url).then(r=>new r.CapacitorNfcWeb)});export{a as CapacitorNfc};
