const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DR9y4jQX.js","./mobile-core-GFRu_HBr.js"])))=>i.map(i=>d[i]);
import{r as t,_ as e}from"./mobile-core-GFRu_HBr.js";const a=t("CapacitorNfc",{web:()=>e(()=>import("./web-DR9y4jQX.js"),__vite__mapDeps([0,1]),import.meta.url).then(r=>new r.CapacitorNfcWeb)});export{a as CapacitorNfc};
