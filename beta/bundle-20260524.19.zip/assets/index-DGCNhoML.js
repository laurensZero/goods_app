const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-3kgIQRkx.js","./mobile-core-DG61eKPa.js"])))=>i.map(i=>d[i]);
import{r as t,_ as e}from"./mobile-core-DG61eKPa.js";const a=t("CapacitorNfc",{web:()=>e(()=>import("./web-3kgIQRkx.js"),__vite__mapDeps([0,1]),import.meta.url).then(r=>new r.CapacitorNfcWeb)});export{a as CapacitorNfc};
