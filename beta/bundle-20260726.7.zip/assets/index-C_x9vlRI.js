const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DZDxQOMm.js","./mobile-core-B-Ii5Svm.js"])))=>i.map(i=>d[i]);
import{r as t,_ as e}from"./mobile-core-B-Ii5Svm.js";const a=t("CapacitorNfc",{web:()=>e(()=>import("./web-DZDxQOMm.js"),__vite__mapDeps([0,1]),import.meta.url).then(r=>new r.CapacitorNfcWeb)});export{a as CapacitorNfc};
