const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DJezaUcB.js","./mobile-core-B-Ii5Svm.js"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./mobile-core-B-Ii5Svm.js";const _=r("Share",{web:()=>t(()=>import("./web-DJezaUcB.js"),__vite__mapDeps([0,1]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
