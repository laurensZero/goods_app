const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DyFyXv0P.js","./mobile-core-mzmcy7uc.js"])))=>i.map(i=>d[i]);
import{r as t,_ as e}from"./mobile-core-mzmcy7uc.js";const a=t("CapacitorNfc",{web:()=>e(()=>import("./web-DyFyXv0P.js"),__vite__mapDeps([0,1]),import.meta.url).then(r=>new r.CapacitorNfcWeb)});export{a as CapacitorNfc};
