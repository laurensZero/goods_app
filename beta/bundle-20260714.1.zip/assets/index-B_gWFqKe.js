const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C4cw93Ct.js","./mobile-core-LrNVZiEn.js"])))=>i.map(i=>d[i]);
import{r as t,_ as e}from"./mobile-core-LrNVZiEn.js";const a=t("CapacitorNfc",{web:()=>e(()=>import("./web-C4cw93Ct.js"),__vite__mapDeps([0,1]),import.meta.url).then(r=>new r.CapacitorNfcWeb)});export{a as CapacitorNfc};
