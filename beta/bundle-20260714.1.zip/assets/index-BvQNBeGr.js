const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DCUJxsQR.js","./mobile-core-LrNVZiEn.js"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./mobile-core-LrNVZiEn.js";const _=r("Share",{web:()=>t(()=>import("./web-DCUJxsQR.js"),__vite__mapDeps([0,1]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
